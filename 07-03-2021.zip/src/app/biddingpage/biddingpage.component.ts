import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-biddingpage',
  templateUrl: './biddingpage.component.html',
  styleUrls: ['./biddingpage.component.css']
})
export class BiddingpageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
