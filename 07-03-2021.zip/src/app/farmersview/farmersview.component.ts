import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-farmersview',
  templateUrl: './farmersview.component.html',
  styleUrls: ['./farmersview.component.css']
})
export class FarmersviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
