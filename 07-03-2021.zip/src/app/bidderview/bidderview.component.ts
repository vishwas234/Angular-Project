import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bidderview',
  templateUrl: './bidderview.component.html',
  styleUrls: ['./bidderview.component.css']
})
export class BidderviewComponent implements OnInit {

  constructor() { }
  viewbids() {

  }
  viewlands() { }

  ngOnInit(): void {
  }

}
