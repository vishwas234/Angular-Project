import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bidderheader',
  templateUrl: './bidderheader.component.html',
  styleUrls: ['./bidderheader.component.css']
})
export class BidderheaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
