import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bidder',
  templateUrl: './bidder.component.html',
  styleUrls: ['./bidder.component.css']
})
export class BidderComponent implements OnInit {
  // farmerName: string;
  // address: string;
  // mobile: string;
  // loginId: string;
  // password: string;


  // constructor(farmerName: string, address: string, mobile: string, loginId: string, password: string) {
  //   this.farmerName = farmerName;
  //   this.address = address;
  //   this.mobile = mobile;
  //   this.loginId = loginId;
  //   this.password = password;
  // }
  constructor() { }
  ngOnInit(): void {
  }

}
