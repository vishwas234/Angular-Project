package com.MyProject;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dao.LandDao;
import com.dto.Land;

@RestController
public class LandController {
	@Autowired
	LandDao landDao;

	@RequestMapping("/landRegister")
	public void register() {
		Land land1 = new Land();
		land1.setSurveyNo(1);
		land1.setArea(125);
		land1.setPrice(7500);
		Land land2 = new Land();
		land2.setSurveyNo(2);
		land2.setArea(225);
		land2.setPrice(8500);

		landDao.register(land1);
		landDao.register(land2);
	}

	@RequestMapping("/showAllLands")
	public List<Land> showAllLands() {
		List<Land> landList = landDao.getLand();
		return landList;
	}

	@PostMapping("/EditLand")
	public void updateLand(@RequestBody Land land) {
		landDao.updateLand(land);
	}

	@PostMapping("/DeleteLand")
	public void deleteLand(@RequestBody Land land) {
		landDao.deleteLand(land);
	}
}