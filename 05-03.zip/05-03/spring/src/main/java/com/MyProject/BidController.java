package com.MyProject;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dao.BidDao;
import com.dto.Bid;

@RestController
public class BidController {
	@Autowired
	BidDao bidDao;

	@RequestMapping("/bidRegister")
	public void register() {
		Bid bid1 = new Bid();
		bid1.setBidId(1);
		bid1.setBidValue(15000);
		Bid bid2 = new Bid();
		bid2.setBidId(2);
		bid2.setBidValue(21000);
		bidDao.register(bid1);
		bidDao.register(bid2);

	}

	@RequestMapping("/showAllBids")
	public List<Bid> showAllBids() {

		List<Bid> bidList = bidDao.getBid();
		return bidList;
	}

	@RequestMapping("/showBidById/{bidId}")
	public Bid showBidById(@PathVariable("bidId") int bidId) {
		Bid bid = bidDao.getBidById(bidId);
		return bid;
	}

	@PostMapping("/EditBid")
	public void updateBid(@RequestBody Bid bid) {
		bidDao.updateBid(bid);
	}

	@PostMapping("/DeleteBid")
	public void deleteBid(@RequestBody Bid bid) {
		bidDao.deleteBid(bid);
	}

	/*
	 * @DeleteMapping("/showBidById") public @ResponseBody ResponseEntity < String >
	 * deletePerson() { return new ResponseEntity < String >
	 * ("Response from DELETE method", HttpStatus.OK);
	 */
}
