package com.MyProject;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dao.BidderDao;
import com.dto.Bidder;

@RestController

public class BidderController {

	@Autowired
	BidderDao bidderDao;

	@RequestMapping("/bidderRegister")
	public void register() {

		Bidder bidder1 = new Bidder();
		bidder1.setBidderName("swadeep");
		bidder1.setContactNumber(895645);
		bidder1.setAddress("telangana");
		bidder1.setLoginId("swadeep123");
		bidder1.setPassword("password");

		Bidder bidder2 = new Bidder();
		bidder2.setBidderName("vishwas");
		bidder2.setContactNumber(7595645);
		bidder2.setAddress("sec");
		bidder2.setLoginId("vishwas123");
		bidder2.setPassword("password");

		bidderDao.register(bidder1);
		bidderDao.register(bidder2);

	}

	@RequestMapping("/showAllBidders")
	public List<Bidder> showAllBidders() {
		List<Bidder> bidderList = bidderDao.getBidder();
		return bidderList;
	}

	@RequestMapping("/showBidderById/{bidderId}")
	public Bidder showBidderById(@PathVariable("bidderId") Integer bidderId) {
		Bidder bidder = bidderDao.getBidderById(bidderId);
		return bidder;
	}

	@PostMapping("/EditBidder")
	public void updateBidder(@RequestBody Bidder bidder) {
		bidderDao.updateBidder(bidder);
	}

	@PostMapping("/DeleteBidder")
	public void deleteBidder(@RequestBody Bidder bidder) {
		bidderDao.deleteBidder(bidder);
	}

}
