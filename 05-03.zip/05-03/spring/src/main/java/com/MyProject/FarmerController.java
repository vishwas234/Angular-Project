package com.MyProject;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dao.FarmerDao;
import com.dto.Farmer;

@RestController
public class FarmerController {

	@Autowired
	FarmerDao farmerDao;

	@RequestMapping("/farmerRegister")
	public void register() {

		Farmer farmer1 = new Farmer();
		farmer1.setFarmerName("Bala");
		farmer1.setMobile(1154256);
		farmer1.setAddress("Andhra");
		farmer1.setLoginId("bala123");
		farmer1.setPassword("password");

		Farmer farmer2 = new Farmer();
		farmer2.setFarmerName("SaiNath");
		farmer2.setMobile(45154256);
		farmer2.setAddress("telangana");
		farmer2.setLoginId("sainath123");
		farmer2.setPassword("password");

		farmerDao.register(farmer1);
		farmerDao.register(farmer2);

	}

	@RequestMapping("/showAllFarmers")
	public List<Farmer> showAllFarmers() {
		List<Farmer> farmerList = farmerDao.getFarmer();
		return farmerList;

	}

	@PostMapping("/EditFarmer")
	public void updateFarmer(@RequestBody Farmer farmer) {
		farmerDao.updateFarmer(farmer);
	}

	@PostMapping("/DeleteFarmer")
	public void deleteFarmer(@RequestBody Farmer farmer) {
		farmerDao.deleteFarmer(farmer);
	}

}
