package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dto.Farmer;

@Service
public class FarmerDao {

	@Autowired
	FarmerRepository farmerRepository;

	public void register(Farmer farmer) {
		farmerRepository.save(farmer);
	}

	public List<Farmer> getFarmer() {
		List<Farmer> farmerList = farmerRepository.findAll();
		return farmerList;
	}

	public void deleteFarmer(Farmer farmer) {

		farmerRepository.delete(farmer);
	}

	public void updateFarmer(Farmer farmer) {
		farmerRepository.save(farmer);
	}
}
