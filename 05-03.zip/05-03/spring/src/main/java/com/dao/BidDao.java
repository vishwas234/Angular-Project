package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dto.Bid;

@Service
public class BidDao {
	@Autowired
	BidRepository bidRepository;

	public void register(Bid bid) {
		bidRepository.save(bid);
	}

	public List<Bid> getBid() {
		List<Bid> bidList = bidRepository.findAll();
		return bidList;
	}

	public Bid getBidById(int bidId) {
		Bid bid = bidRepository.findById(bidId).orElse(new Bid());
		return bid;

	}

	public void updateBid(Bid bid) {
		bidRepository.save(bid);
	}

	public void deleteBid(Bid bid) {

		bidRepository.delete(bid);

	}
}
