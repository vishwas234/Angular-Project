package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dto.Land;

@Service
public class LandDao {

	@Autowired
	LandRepository landRepository;

	public void register(Land land) {
		landRepository.save(land);
	}

	public List<Land> getLand() {
		List<Land> landList = landRepository.findAll();
		return landList;

	}

	public void updateLand(Land land) {
		landRepository.save(land);
	}

	public void deleteLand(Land land) {
		landRepository.delete(land);
	}
}
