package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dto.Bidder;

@Service
public class BidderDao {

	@Autowired
	BidderRepository bidderRepository;

	public void register(Bidder bidder) {
		bidderRepository.save(bidder);
	}

	public List<Bidder> getBidder() {
		List<Bidder> bidderList = bidderRepository.findAll();
		return bidderList;
	}

	public Bidder getBidderById(Integer bidderId) {

		Bidder bidder = bidderRepository.findById(bidderId).orElse(new Bidder());
		return bidder;
	}

	public void updateBidder(Bidder bidder) {
		bidderRepository.save(bidder);
	}

	public void deleteBidder(Bidder bidder) {
		bidderRepository.delete(bidder);
	}

}
