import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewlands',
  templateUrl: './viewlands.component.html',
  styleUrls: ['./viewlands.component.css']
})
export class ViewlandsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
