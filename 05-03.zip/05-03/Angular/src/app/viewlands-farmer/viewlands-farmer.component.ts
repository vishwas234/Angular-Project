import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewlands-farmer',
  templateUrl: './viewlands-farmer.component.html',
  styleUrls: ['./viewlands-farmer.component.css']
})
export class ViewlandsFarmerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
