import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(public router: Router) { }

  ngOnInit(): void {
  }
  submitLoginForm(loginForm: any): void {

    console.log(loginForm);
    if (loginForm.loginId === 'farmer' && loginForm.password === 'password') {
      this.router.navigate(['farmersview']);
    }
    else if (loginForm.loginId === 'bidder' && loginForm.password === 'password') {
      this.router.navigate(['bidderview']);
    }
  }
}
