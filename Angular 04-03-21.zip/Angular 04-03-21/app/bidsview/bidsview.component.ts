import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bidsview',
  templateUrl: './bidsview.component.html',
  styleUrls: ['./bidsview.component.css']
})
export class BidsviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
