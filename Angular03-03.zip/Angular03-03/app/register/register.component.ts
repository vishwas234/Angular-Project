import { BidderService } from './../bidder.service';
import { FarmerService } from './../farmer.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  Farmerservice: FarmerService
  Bidderservice: BidderService
  constructor() { }

  ngOnInit(): void {
  }

  registeruser(regForm: any) {

    if (regForm.selector === "1") {

      console.log(regForm);

      //this.Bidderservice.register(regForm).subscribe((result: any) => console.log(result));
    }

    else if (regForm.selector === "2") {
      //  console.log(regForm);
      //  this.Farmerservice.register(regForm).subscribe((result: any) => console.log(result));
    }
  }
}




