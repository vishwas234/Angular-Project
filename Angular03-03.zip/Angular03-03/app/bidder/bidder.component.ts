import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bidder',
  templateUrl: './bidder.component.html',
  styleUrls: ['./bidder.component.css']
})
export class BidderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
