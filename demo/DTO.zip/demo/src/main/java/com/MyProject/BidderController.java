package com.MyProject;

import java.util.List;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dao.BidderDao;
import com.dao.FarmerDao;
import com.dto.Bidder;
import com.dto.Farmer;

@RestController
public class BidderController {
	@RequestMapping("/getBidder")
    public Bidder  getBidder() {
    	Bidder b  =  new Bidder();
    	b.setBidderId(1);
    	b.setBidderName("swadeep");
    	b.setContactNumber(895645);
    	b.setAddress("telangana");
    	b.setLoginId("swadeep123");
    	b.setPassword("password");
    	return b;

    }
	

	@RequestMapping("/getAllBidders")
	public List<Bidder> getAllBidders(){
		BidderDao bidderDao = new BidderDao();
		List<Bidder> bidderList = bidderDao.getAllBidders();
		return bidderList;
	}
	
	@PostMapping("/registerBidder")
	public void register(Bidder bidder) {
		BidderDao bidderDao = new BidderDao();
		bidderDao.registerBidder(bidder);
	}
}
