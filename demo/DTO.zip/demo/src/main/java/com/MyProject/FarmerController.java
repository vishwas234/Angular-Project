package com.MyProject;

import java.util.List;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dao.BidderDao;
import com.dao.FarmerDao;
import com.dto.Bidder;
import com.dto.Farmer;


@RestController
public class FarmerController {
	
	
	
	@RequestMapping("/getFarmer")
	public Farmer showFarmer() {
	Farmer P = new Farmer();
	P.setFarmerId(1);
	P.setFarmerName("Bala Chandrudu");
	P.setMobile(733066);
	P.setAddress("Andhra Pradesh");
	P.setLoginId("Bala123");
	P.setPassword("password");
	return P;
	
	}
	@PostMapping("/registerFarmer")
	public void register(Farmer farmer) {
		FarmerDao farmerDao = new FarmerDao();
		farmerDao.registerFarmer(farmer);
	}

	@RequestMapping("/getAllFarmers")
	public List<Farmer> getAllFarmers(){
		
		FarmerDao farmerDao = new FarmerDao();
		List<Farmer> farmerList = farmerDao.getAllFarmers();
		return farmerList;
	}
}
