package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dto.Bidder;

@Service
public class BidderDao {  
	@Autowired
	BidderRepository  bidderRepository;
	public List<Bidder> getAllBidders(){
		return  bidderRepository.findAll();
		
	}
	
	public void registerBidder(Bidder bidder){
		bidderRepository.save(bidder);
				}
}
